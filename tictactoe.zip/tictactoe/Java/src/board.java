/* 		Note Changed
 * 11/15 	Making the button disable after one click . Enable it after Reset
 * 			Checkwin() will always have the right array [index] to work with.		
 *  		Write CheckR() and CheckL() to check what if the input is on the middle.
 *  		Fix CheckR() so that when index is [0] there wont be a out of bound errors. 
 * Thing need to do:
 * 			Logic Error: program won't recognize if it a win if we place x in the middle 
 * 			it can only check all right or all left but not if final placement is in the middle. 
 *   
 *  
 *                                        */

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.*;
import javax.swing.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;



public class board extends JPanel {
	int bSize = 25;
	int column = 5, row = 5 ;
	int win = 4;
	int winnerCounter = 0;
	int AIturn = 0;
	int maximumR = 8;
	JButton buttons[] = new JButton[bSize];
	int xo = 0 ; // 0 = x ; 1 = O
	List<Integer> list = new ArrayList<>();
	
	
	public board() {
		setLayout(new GridLayout(column,row));
		placeButtons();
		randomXO();

	}
	
	public void placeButtons() {
		for(int c = 0 ; c <bSize; c++) {
			buttons[c] = new JButton();
			buttons[c].putClientProperty("array", c);
			buttons[c].setText("");
            buttons[c].addActionListener(new buttonListener());			
			add(buttons[c]);
		}
	}
	
	public void resetButtons() { // This can be fix 
		for(int c = 0; c < bSize; c++)
		{
			buttons[c].setEnabled(true);
			buttons[c].setText("");
		}	
		winnerCounter++;
		xo = 0;
		randomXO();
	}
	
	public void randomXO() {
		int randomNum = ((int)(Math.random()* (maximumR/2)))*2; // 0 - 6 even Random moves
		AIturn = randomNum;
		setupUniqueR();
		for(int c = 0; c < randomNum ; c++ ) { 
			int randomPlaces =  list.get(c);
			if(xo%2 == 0) {
				buttons[randomPlaces].setText("X");
			}
			else {
				buttons[randomPlaces].setText("O");
           }
			xo++;
			buttons[randomPlaces].setEnabled(false);
		}
	}
	
	
	public void setupUniqueR() {
		for (int i=0; i< bSize; i++) {
		     list.add(i);
		}
		Collections.shuffle(list);
	}
	

	
	private class buttonListener implements ActionListener

	{
	
	public void actionPerformed(ActionEvent j)
		{
			JButton buttonClicked = (JButton)j.getSource();
			if(buttonClicked.getText() == "") {	
				if(xo%2 == 0) {
				     buttonClicked.setText("X");
				     xo++;  
				}
				else if((xo+1)%2 == 0) {
	                buttonClicked.setText("O");
	                xo++;  
	            }
		         //xo++;   
	             buttonClicked.setEnabled(false); // Disable Buttons after clicked
			}	
            	
      
			
			 if(checkWin((int) buttonClicked.getClientProperty("array")) && xo <= 25) // Sending Array Index // Check in or tie
	            { 
				 if ((xo%2 == 0)){  JOptionPane.showMessageDialog(null, "O win"); }
				 else { JOptionPane.showMessageDialog(null, "X win");	}
				 displayOption();
	            }
			 if (xo== 25 && !checkWin((int) buttonClicked.getClientProperty("array")) ) {
				 JOptionPane.showMessageDialog(null, "Tie"); // bug last move win doesn't count
				 displayOption();
			 }
			 hardAI((int) buttonClicked.getClientProperty("array"));
			 //easyAI();
			 if(checkWin((int) buttonClicked.getClientProperty("array")) && xo <= 25) // Sending Array Index // Check in or tie
	            { 
				 if ((xo%2 == 0)){  JOptionPane.showMessageDialog(null, "O win"); }
				 else { JOptionPane.showMessageDialog(null, "X win");	}
				 displayOption();
	            }
			 if (xo== 25 && !checkWin((int) buttonClicked.getClientProperty("array")) ) {
				 JOptionPane.showMessageDialog(null, "Tie"); // bug last move win doesn't count
				 displayOption();
			 }
			 
		}

		
	public void displayOption() {
		Object[] options = {" Yes", "No"};
	 		int c = JOptionPane.showOptionDialog(null,"Game Over. Retry?", "Select an Option"
			,JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE
			,null, options,null);
	 	if(JOptionPane.NO_OPTION == c) {
	 		System.exit(0);
	 	}
	 	if(JOptionPane.YES_OPTION == c) {
	 		resetButtons();
	 	}
	}
	
	public boolean checkWin(int a) { 
       return (    checkVertical(a) >= win || checkHorizontal(a) >= win ||  checkDiagonalL(a) >= win  || checkDiagonalR(a) >= win  ) ;  
	}
	
	public int checkVertical(int a) {
		int counter = 1; 
		int temp = a;
		while (checkD(temp)) {
			counter++; 
			temp += 5;
		}
		temp = a; // Bug fix
		while (checkU(temp)) {
			counter++;
			temp -= 5;
		}
		return counter;
	}
	
	public int checkHorizontal(int a) {
		int counter = 1; 
		int temp = a;
		while (checkR(temp)) {
			counter++;
			temp++;
		}
		temp = a; // Bug fix
		while (checkL(temp)) {
			counter++;
			temp--;
		}
		return counter;
	}
	
	public int checkDiagonalL(int a)  { // /
		int counter = 1; 
		int temp = a;
		while (checkUR(temp) ) {
			counter++; 
			temp -= 4;
		}
		temp = a; 
		while (checkDL(temp)) {
			counter++;
			temp += 4;
		}
		return counter;
    }
	
	public int checkDiagonalR(int a)  { // \
		int counter = 1; 
		int temp = a;
		while (checkUL(temp) ) {
			counter++; 
			temp -= 6;
		}
		temp = a; 
		while (checkDR(temp)) {
			counter++;
			temp += 6;
		}
		return counter;
    }
	
	public boolean checkD(int a) {
		if (a == bSize-1 || a > 19) return false; // if index 0 return false
		return ( !buttons[a].getText().equals("")  
				 && buttons[a].getText().equals(buttons[a+5].getText())
				);
	}
	public boolean checkU(int a) {
		if (a < 5) return false; // if index 0 return false
		return ( !buttons[a].getText().equals("")  
				 && buttons[a].getText().equals(buttons[a-5].getText()) 
				) ;
	}
	public boolean checkR(int a) {
		if( a >= bSize-1 || (a+1)%column == 0  ) return false;
		return  (buttons[a].getText().equals(buttons[a+1].getText())  // Equal to the Right one
				 && !buttons[a].getText().equals("")   // Not blank
				) ;
	}
	public boolean checkL(int a) {
		if (a <= 0 || a%column == 0 ) return false; // if index 0 return false
		return ( !buttons[a].getText().equals("")  
				 && buttons[a].getText().equals(buttons[a-1].getText()) 
				) ;
	}
	public boolean checkDL(int a) {
		if (a%column == 0 || a > 19) return false; 
		return ( !buttons[a].getText().equals("")  
				 && buttons[a].getText().equals(buttons[a+4].getText()) 
				) ;
	}
	public boolean checkDR(int a) {
		if ((a+1)%column == 0 || a > 18) return false;
		return ( !buttons[a].getText().equals("")  
				 && buttons[a].getText().equals(buttons[a+6].getText()) 
				) ;
	}
	public boolean checkUL(int a) {
		if (a < 6 || a > bSize-1 || a%column == 0 ) return false; 
		return ( !buttons[a].getText().equals("")  
				 && buttons[a].getText().equals(buttons[a-6].getText()) 
				) ;
	}
	public boolean checkUR(int a) {
		if (a < row || (a+1)%column == 0 || a > bSize-2 ) return false; //a < 5 and a != 9 14 19 
		return ( !buttons[a].getText().equals  ("")  
				 && buttons[a].getText().equals(buttons[a-4].getText()) 
				) ;
	}
	
	public String stringXO() {
		if( xo % 2 == 0 ) return "X";
		return "O";
	}
	
	public void easyAI() {
		boolean move = true;

		while(move) {
			int randomPlaces =  list.get(AIturn);
			if(buttons[randomPlaces].isEnabled()) {
				if(xo%2 == 0) {
					buttons[randomPlaces].setText("X");
				}
				else {
					buttons[randomPlaces].setText("O");
	           }
				buttons[randomPlaces].setEnabled(false);
				xo++;
				move = false;
			}
			AIturn++;		
		}
	}
	
	public void hardAI(int lastPOS) {
		int checkPoint = 2;
		int[] arr;
		arr = new int[4]; 
		int temp, i = 0;
		
		arr[0] = checkVertical(lastPOS);
		arr[1] = checkHorizontal(lastPOS);
		arr[2] = checkDiagonalL(lastPOS);
		arr[3] = checkDiagonalR(lastPOS);
		//
		temp = arr[0];
		for(int c = 0; c < 4; c++) {
			if(temp < arr[c]) {
				i = c;
			}
		}
		temp = xo;
		switch(i) {
			case 0:
				if(checkVertical(lastPOS) >= checkPoint ) {
					if(	 lastPOS < 22 && buttons[lastPOS+5].isEnabled() ) {
						buttons[lastPOS+5].setText(stringXO());
						buttons[lastPOS+5].setEnabled(false);
						xo++;
					}
					else if(	lastPOS > 6 && buttons[lastPOS-5].isEnabled() ) {
						buttons[lastPOS-5].setText(stringXO());
						buttons[lastPOS-5].setEnabled(false);
						xo++;
					}
				
					else if(	 lastPOS < 14 && buttons[lastPOS+10].isEnabled() ) {
						buttons[lastPOS+10].setText(stringXO());
						buttons[lastPOS+10].setEnabled(false);
						xo++;
					}
					else if(	lastPOS > 10 && buttons[lastPOS-10].isEnabled() ) {
						buttons[lastPOS-10].setText(stringXO());
						buttons[lastPOS-10].setEnabled(false);
						xo++;
					}
				}
				break;
			case 1:
				if(checkHorizontal(lastPOS) >= checkPoint ) {
					if(	 lastPOS < 24 && buttons[lastPOS+1].isEnabled() ) {
						buttons[lastPOS+1].setText(stringXO());
						buttons[lastPOS+1].setEnabled(false);
						xo++;
					}
					else if(lastPOS > 0 && buttons[lastPOS-1].isEnabled() ) {
						buttons[lastPOS-1].setText(stringXO());
						buttons[lastPOS-1].setEnabled(false);
						xo++;
					}
					else if(lastPOS < 22 && buttons[lastPOS+2].isEnabled() ) {
						buttons[lastPOS+2].setText(stringXO());
						buttons[lastPOS+2].setEnabled(false);
						xo++;
					}
					else if(	lastPOS > 2 && buttons[lastPOS-2].isEnabled() ) {
						buttons[lastPOS-2].setText(stringXO());
						buttons[lastPOS-2].setEnabled(false);
						xo++;
					}
					
				}
				break;
			case 2:
				if(checkDiagonalL(lastPOS) >= checkPoint ) {// /
					if(	 lastPOS < 21 && buttons[lastPOS+4].isEnabled() && lastPOS % 5 !=0 ) {
						buttons[lastPOS+4].setText(stringXO());
						buttons[lastPOS+4].setEnabled(false);
						xo++;
					}
					else if(	lastPOS > 3 && buttons[lastPOS-4].isEnabled() && lastPOS+1 % 5 != 0) {
						buttons[lastPOS-4].setText(stringXO());
						buttons[lastPOS-4].setEnabled(false);
						xo++;
					}
					else if(lastPOS < 17  && buttons[lastPOS+8].isEnabled() && lastPOS % 5 !=0 ) {
						buttons[lastPOS+8].setText(stringXO());
						buttons[lastPOS+8].setEnabled(false);
						xo++;
					}
					else if(	lastPOS > 5 && buttons[lastPOS-8].isEnabled() && lastPOS+1 % 5 != 0) {
						buttons[lastPOS-8].setText(stringXO());
						buttons[lastPOS-8].setEnabled(false);
						xo++;
					}
				}
				break;
			case 3:
				if(checkDiagonalR(lastPOS) >= checkPoint ) {// \
					if(	 lastPOS <  19 & buttons[lastPOS+6].isEnabled() ) {
						buttons[lastPOS+6].setText(stringXO());
						buttons[lastPOS+6].setEnabled(false);
						xo++;
					}
					else if(	lastPOS >= 6 && buttons[lastPOS-6].isEnabled()) {
						buttons[lastPOS-6].setText(stringXO());
						buttons[lastPOS-6].setEnabled(false);
						xo++;
					}
					else if(	 lastPOS <= 12 && buttons[lastPOS+12].isEnabled() ) {
						buttons[lastPOS+12].setText(stringXO());
						buttons[lastPOS+12].setEnabled(false);
						xo++;
					}
					else if(	lastPOS >= 12 && buttons[lastPOS-12].isEnabled()) {
						buttons[lastPOS-12].setText(stringXO());
						buttons[lastPOS-12].setEnabled(false);
						xo++;
					}
				}
			break;
		}
			
		if(temp == xo) {
			easyAI();
			xo++;
			System.out.println("EASY AI WORKING");
		}
		System.out.println(xo);
	}
	
}
	  public static void main(String[] args)  {

		 JFrame window = new JFrame("Tic-Tac-Toe");
	     window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	     window.getContentPane().add(new board());
	     window.setBounds(500,200,500,500);
	     window.setVisible(true);
	  }

    

}


